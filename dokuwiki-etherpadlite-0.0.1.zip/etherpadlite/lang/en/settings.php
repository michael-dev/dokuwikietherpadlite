<?php
/**
 * @author Michael Braun <michael-dev@fami-braun.de>
 */


$lang['etherpadlite_url'] = "Url of etherpad lite";
$lang['etherpadlite_apikey'] = "APIKEY of etherpad lite";
$lang['etherpadlite_group'] = "Alias of etherpad lite group";
$lang['etherpadlite_domain'] = "shared cookie-domain for etherpad lite";
