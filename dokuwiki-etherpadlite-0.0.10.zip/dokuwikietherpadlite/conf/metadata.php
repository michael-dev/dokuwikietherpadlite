<?php
/**
 * Options for the etherpadlite plugin
 *
 * @author Michael Braun <michael-dev@fami-braun.de>
 */


$meta['etherpadlite_url'] = array('string');
$meta['etherpadlite_apikey'] = array('string');
$meta['etherpadlite_group']  = array('string');
$meta['etherpadlite_domain']  = array('string');
$meta['etherpadlite_urlargs'] = array('string');
