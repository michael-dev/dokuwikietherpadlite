<?php
/**
 * @author Michael Braun <michael-dev@fami-braun.de>
 */


$lang['etherpadlite_url'] = "URL des Etherpad Lite";
$lang['etherpadlite_apikey'] = "APIKEY des Etherpad Lite";
$lang['etherpadlite_group'] = "Etherpad-Gruppenalias für Etherpad Lite";
$lang['etherpadlite_domain'] = "Gemeinsame Cookie-Domain für Etherpad Lite";
